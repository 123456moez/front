from django.urls import path
from .views import  candidate_signup, delete_candidate, delete_cv, delete_recruiter, get_all_candidates, get_all_recruiters, get_all_users,  get_candidate_profile, get_recruiter_profile,  google_login, recruiter_signup,login, update_candidate_profile, update_recruiter_profile, update_user, upload_cv, user_delete, user_update
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
    TokenVerifyView,
)


urlpatterns = [

    
    path('login/',login,name='login'),
    path('update_user/<int:id>/', update_user, name='update_user'),
    

    path('candidatProfile/', get_candidate_profile, name='get_candidate_profile'),
    path('signup/candidat/', candidate_signup, name='candidate-signup'),
    path('update_candidate/<int:candidate_id>/', update_candidate_profile, name='update_candidate'),
    path('delete_candidate/<int:id>/', delete_candidate, name='delete_user'),
    path('delete_cv/<int:user_id>/', delete_cv, name='delete_cv'),
    path('upload-cv/', upload_cv, name='upload_cv'),
    

    path('signup/recruteur/', recruiter_signup, name='recruiter-signup'),
    path('update_recruiter/<int:recruiter_id>/', update_recruiter_profile, name='recruiter-update'),
    path('delete_recruiter/<int:recruiter_id>/', delete_recruiter, name='delete-recruiter'),
    path('get_recruiter_profile/', get_recruiter_profile, name='get_recruiter_profile'), 

    path('auth/google/', google_login, name='google-login'),
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('auth/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('api/token/verify/', TokenVerifyView.as_view(), name='token_verify'),


    path('users/', get_all_users),
    path('candidates/', get_all_candidates, name='get_all_candidates'),
    path('recruiters/', get_all_recruiters, name='get_all_recruiters'),
    path('user/update/<int:pk>/', user_update, name='user-update'),
    path('user/delete/<int:pk>/', user_delete, name='delete'),

]   
