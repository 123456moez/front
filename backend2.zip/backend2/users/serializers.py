import base64
from rest_framework import serializers
from .models import User, CandidateProfile, RecruiterProfile
from django.core.files.base import ContentFile

from django.contrib.auth.hashers import make_password

from rest_framework import serializers
from .models import CandidateProfile


from .models import User, CandidateProfile
class UserSerializer(serializers.ModelSerializer):
    
    password = serializers.CharField(write_only=True, required=False)  # Mot de passe est optionnel

    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'password', 'role', 'is_active', 'is_staff']

    def update(self, instance, validated_data):
        # Si un mot de passe est fourni, on le met à jour
        password = validated_data.pop('password', None)
        if password:
            instance.password = make_password(password)

        # Mettre à jour les autres champs
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()
        return instance


class CandidateSignupSerializer(serializers.ModelSerializer):
    user = UserSerializer()
    cv = serializers.CharField(required=True)  # Accepter une chaîne base64

    class Meta:
        model = CandidateProfile
        fields = ['id', 'user', 'cv']

    def create(self, validated_data):
        user_data = validated_data.pop('user')
        user = User.objects.create_user(**user_data, role='candidate')

        # Décoder le fichier base64
        cv_base64 = validated_data.pop('cv')
        format, cv_str = cv_base64.split(';base64,')  # Séparer le préfixe
        ext = format.split('/')[-1]  # Extraire l'extension du fichier
        cv_file = ContentFile(base64.b64decode(cv_str), name=f"cv.{ext}")

        # Crée le profil candidat
        candidate = CandidateProfile.objects.create(user=user, cv=cv_file)
        return candidate


    

class CandidateProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = CandidateProfile
        fields = ['user', 'cv']

    def to_representation(self, instance):
        # Personnalisez la représentation des données
        representation = super().to_representation(instance)
        representation['user'] = {
            'username': instance.user.username,
            'email': instance.user.email,
        }
        representation['cv'] = instance.cv.url if instance.cv else None
        return representation
    
class UpdateCandidateSerializer(serializers.ModelSerializer):
        user = UserSerializer()
    
        class Meta:
            model = CandidateProfile
            fields = ['id', 'user', 'cv']
    
        def update(self, instance, validated_data):
            user_data = validated_data.pop('user', None)
            if user_data:
                user_serializer = UserSerializer(instance.user, data=user_data, partial=True)
                if user_serializer.is_valid():
                    user_serializer.save()
            return super().update(instance, validated_data)
        

class RecruiterSignupSerializer(serializers.ModelSerializer):
    user = UserSerializer()  # Utilisation de UserSerializer pour l'utilisateur
    company_name = serializers.CharField(required=True)  # Champ obligatoire
    contact_email = serializers.EmailField(required=True)  # Champ obligatoire

    class Meta:
        model = RecruiterProfile
        fields = ['user', 'company_name', 'contact_email']

    def create(self, validated_data):
        # Crée l'utilisateur
        user_data = validated_data.pop('user')
        user = User.objects.create_user(**user_data, role='recruiter')

        # Crée le profil recruteur
        recruiter_profile = RecruiterProfile.objects.create(user=user, **validated_data)
        return recruiter_profile
        

        
class UpdateRecruiterSerializer(serializers.ModelSerializer):
    user = UserSerializer()

    class Meta:
        model = RecruiterProfile
        fields = ['id', 'user', 'company_name', 'contact_email']

    def update(self, instance, validated_data):
        user_data = validated_data.pop('user', None)
        if user_data:
            user_serializer = UserSerializer(instance.user, data=user_data, partial=True)
            if user_serializer.is_valid():
                user_serializer.save()
        return super().update(instance, validated_data)
    
class RecruiterProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = RecruiterProfile
        fields = ['id', 'user', 'company_name', 'contact_email']

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        representation['user'] = {
            'username': instance.user.username,
            'email': instance.user.email,
        }
        return representation