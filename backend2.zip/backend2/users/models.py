from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin, Permission, Group
from django.db import models
from django.core.validators import FileExtensionValidator, MaxValueValidator


# Custom User Manager
class CustomUserManager(BaseUserManager):
    def create_user(self, email, username, password=None, **extra_fields):
        if not email:
            raise ValueError("L'adresse email est obligatoire.")
        email = self.normalize_email(email)
        user = self.model(email=email, username=username, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, username, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        if extra_fields.get('is_staff') is not True:
            raise ValueError("Le superutilisateur doit avoir is_staff=True.")
        if extra_fields.get('is_superuser') is not True:
            raise ValueError("Le superutilisateur doit avoir is_superuser=True.")

        return self.create_user(email, username, password, **extra_fields)


# Custom Permission
class CustomPermission(Permission):
    description = models.CharField(max_length=255, blank=True, null=True, verbose_name="Description")

    def __str__(self):
        return f"{self.name} - {self.description}"


# Custom Group
class CustomGroup(Group):
    description = models.CharField(max_length=255, blank=True, null=True, verbose_name="Description")

    def __str__(self):
        return f"{self.name} - {self.description}"

from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin
from django.db import models

class User(AbstractBaseUser, PermissionsMixin):
    ROLE_CHOICES = [
        ('candidate', 'Candidate'),
        ('recruiter', 'Recruiter'),
    ]

    email = models.EmailField(unique=True, verbose_name="Adresse e-mail")
    username = models.CharField(max_length=150, unique=True, verbose_name="Nom d'utilisateur")
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default='candidate', verbose_name="Rôle")
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)

    objects = CustomUserManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username', 'role']

    def __str__(self):
        return f"{self.username} ({self.get_role_display()})"


# Classe de base abstraite pour les profils
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="%(class)s_profile")

    class Meta:
        abstract = True  # Ce modèle est abstrait et ne sera pas créé en base de données


# Modèle pour le profil du candidat
class CandidateProfile(Profile):
    cv = models.FileField(
        upload_to='cvs/',
        null=True,
        blank=True,
        verbose_name="CV",
        validators=[
            FileExtensionValidator(allowed_extensions=['pdf']),
            MaxValueValidator(5 * 1024 * 1024)  # Limite à 5 Mo
        ]
    )

    def __str__(self):
        return self.user.username


# Modèle pour le profil du recruteur
class RecruiterProfile(Profile):
    company_name = models.CharField(max_length=255, verbose_name="Nom de l'entreprise")
    contact_email = models.EmailField(null=True ,verbose_name="E-mail de contact")

    def __str__(self):
        return self.company_name