import jwt
from datetime import datetime, timedelta
from django.conf import settings
import uuid  # To generate unique JWT IDs (jti)

class TokenGenerator:
    @staticmethod
    def generate_access_token(user):
        payload = {
            'user_id': user.id,
            'exp': datetime.utcnow() + timedelta(minutes=15),  # Token expires in 15 minutes
            'iat': datetime.utcnow(),
            'jti': str(uuid.uuid4()),  # Add a unique JWT ID
        }
        return jwt.encode(payload, settings.SECRET_KEY, algorithm='HS256')
    # Create a user object


    @staticmethod
    def generate_refresh_token(user):
        payload = {
            'user_id': user.id,
            'exp': datetime.utcnow() + timedelta(days=7),  # Token expires in 7 days
            'iat': datetime.utcnow(),
            'jti': str(uuid.uuid4()),  # Add a unique JWT ID
        }
        return jwt.encode(payload, settings.SECRET_KEY, algorithm='HS256')