import os
from venv import logger

from django.core.exceptions import ObjectDoesNotExist
from django.contrib.auth.hashers import make_password
from django.views.decorators.csrf import csrf_exempt
from rest_framework.decorators import (
    api_view,
    permission_classes,
    parser_classes,
)
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework_simplejwt.tokens import RefreshToken
from google_auth_oauthlib.flow import Flow
from google.oauth2 import id_token
from google.auth.transport import requests as google_requests
from .models import (
    CandidateProfile,
    RecruiterProfile,
    User,
)
from .serializers import (
    CandidateProfileSerializer,
    CandidateSignupSerializer,
    RecruiterProfileSerializer,
    RecruiterSignupSerializer,
    UpdateCandidateSerializer,
    UpdateRecruiterSerializer,
    UserSerializer,
  
)
from .authentication import TokenGenerator


@api_view(['POST'])
@permission_classes([AllowAny])
def candidate_signup(request):
    if request.method == 'POST':
        # Utilisez request.data pour les données JSON et request.FILES pour les fichiers
        data = request.data
        files = request.FILES

        # Combinez les données et les fichiers
        combined_data = {**data, **files}

        serializer = CandidateSignupSerializer(data=combined_data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)





@csrf_exempt
@api_view(['POST'])
def login(request):
    if request.method == 'POST':
        email = request.data.get('email')
        password = request.data.get('password')
        
        # Vérification des champs obligatoires
        if not email or not password:
            return Response(
                {"error": "Email and password are required"},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            # Vérification de l'utilisateur
            user = User.objects.get(email=email)
            if user.check_password(password):
                # Génération des tokens
                access_token = TokenGenerator.generate_access_token(user)
                print("token",access_token)
                refresh_token = TokenGenerator.generate_refresh_token(user)
                
                # Récupération des informations de l'utilisateur
                user_data = {
                    "id": user.id,
                    "email": user.email,
                    "username": user.username,
                    "role": user.role  # Assurez-vous que le champ `role` existe dans le modèle User
                }
                
                # Réponse en cas de succès
                return Response({
                    "access": access_token,
                    "refresh": refresh_token,
                    "user": user_data  # Inclure les informations de l'utilisateur
                }, status=status.HTTP_200_OK)
            else:
                return Response(
                    {"error": "Invalid password"},
                    status=status.HTTP_401_UNAUTHORIZED
                )
        except User.DoesNotExist:
            return Response(
                {"error": "User not found"},
                status=status.HTTP_404_NOT_FOUND
            )



@api_view(['POST'])
def google_login(request):
    id_token_str = request.data.get('idToken')

    if not id_token_str:
        return Response({'error': 'ID token required'}, status=status.HTTP_400_BAD_REQUEST)

    try:
        # Validate Google ID token
        id_info = id_token.verify_oauth2_token(
            id_token_str,
            google_requests.Request(),
            os.getenv('GOOGLE_CLIENT_ID')
        )

        email = id_info['email']
        name = id_info.get('name', '')
        google_id = id_info['sub']

        # Generate a safe username
        base_username = email.split('@')[0][:120]  # Truncate to 120 characters
        unique_username = base_username + '_google'

        # Create or fetch user
        user, created = User.objects.get_or_create(
            email=email,
            defaults={
                'username': unique_username,
                'password': make_password(google_id),  # Hash the Google ID as password
                'role': 'candidate'  # Default role
            }
        )

        # Create profile if the user is newly created
        if created:
            if user.role == 'candidate':
                CandidateProfile.objects.create(user=user)
            elif user.role == 'recruiter':
                RecruiterProfile.objects.create(user=user)

        # Generate JWT tokens
        refresh = RefreshToken.for_user(user)
        
        return Response({
            'access': str(refresh.access_token),
            'refresh': str(refresh),
            'user': UserSerializer(user).data
        })

    except ValueError as e:
        logger.error(f"Google auth error: {str(e)}")
        return Response({'error': 'Invalid Google token'}, status=status.HTTP_401_UNAUTHORIZED)



@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_candidate_profile(request):
    try:
        # Récupérez le profil du candidat associé à l'utilisateur connecté
        candidate_profile = CandidateProfile.objects.get(user=request.user)
        serializer = CandidateProfileSerializer(candidate_profile)
        return Response(serializer.data, status=status.HTTP_200_OK)
    except CandidateProfile.DoesNotExist:
        return Response({"error": "Profil candidat non trouvé."}, status=status.HTTP_404_NOT_FOUND)


@api_view(['PUT'])
def update_user(request, id):
    try:
        user = User.objects.get(id=id)
    except User.DoesNotExist:
        return Response({'error': 'User not found'}, status=status.HTTP_404_NOT_FOUND)

    serializer = UserSerializer(user, data=request.data, partial=True)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
@parser_classes([MultiPartParser, FormParser])
def upload_cv(request):
    user_id = request.data.get('user_id')
    if not user_id:
        return Response({'error': 'User ID is required'}, status=status.HTTP_400_BAD_REQUEST)

    try:
        user_profile = CandidateProfile.objects.get(user__id=user_id)
    except CandidateProfile.DoesNotExist:
        return Response({'error': 'User not found'}, status=status.HTTP_404_NOT_FOUND)

    file = request.FILES.get('file')
    if not file:
        return Response({'error': 'No file provided'}, status=status.HTTP_400_BAD_REQUEST)

    user_profile.cv = file
    user_profile.save()

    file_url = request.build_absolute_uri(user_profile.cv.url)
    return Response({'url': file_url}, status=status.HTTP_201_CREATED)




@api_view(['DELETE'])
def delete_cv(request, user_id):
    try:
        candidate = CandidateProfile.objects.get(user_id=user_id)  # Utilisez CandidateProfile, pas User
        if candidate.cv:
            candidate.cv.delete()  # Supprime le fichier du stockage
            candidate.cv = None
            candidate.save()
            return Response({"message": "CV supprimé avec succès"}, status=status.HTTP_200_OK)
        else:
            return Response({"error": "Aucun CV trouvé"}, status=status.HTTP_404_NOT_FOUND)
    except ObjectDoesNotExist:
        return Response({"error": "Candidat non trouvé"}, status=status.HTTP_404_NOT_FOUND)
    

@api_view(['PUT'])
def update_candidate_profile(request, candidate_id):
    try:
        candidate_profile = CandidateProfile.objects.get(id=candidate_id)
    except CandidateProfile.DoesNotExist:
        return Response({"error": "Candidat non trouvé"}, status=status.HTTP_404_NOT_FOUND)

    if request.method == 'PUT':
        serializer = UpdateCandidateSerializer(candidate_profile, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['DELETE'])
def delete_candidate(request, id):
    try:
        user = User.objects.get(id=id)
    except User.DoesNotExist:
        return Response({'error': 'User not found'}, status=status.HTTP_404_NOT_FOUND)

    user.delete() 
    return Response(status=status.HTTP_204_NO_CONTENT)



@api_view(['GET'])
##@permission_classes([IsAuthenticated])
def get_recruiter_profile(request):
    try:
        # Récupérez le profil du recruteur associé à l'utilisateur connecté
        recruiter_profile = RecruiterProfile.objects.get(user=request.user)
        serializer = RecruiterProfileSerializer(recruiter_profile)
        return Response(serializer.data, status=status.HTTP_200_OK)
    except RecruiterProfile.DoesNotExist:
        return Response({"error": "Profil recruteur non trouvé."}, status=status.HTTP_404_NOT_FOUND)

@api_view(['PUT'])
def update_recruiter_profile(request, recruiter_id):
    try:
        recruiter_profile = RecruiterProfile.objects.get(id=recruiter_id)
    except RecruiterProfile.DoesNotExist:
        return Response({"error": "Recruiter not found"}, status=status.HTTP_404_NOT_FOUND)

    if request.method == 'PUT':
        serializer = UpdateRecruiterSerializer(recruiter_profile, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
@api_view(['DELETE'])
def delete_recruiter(request, recruiter_id):
    try:
        recruiter_profile = RecruiterProfile.objects.get(id=recruiter_id)
    except RecruiterProfile.DoesNotExist:
        return Response({"error": "Recruteur non trouvé"}, status=status.HTTP_404_NOT_FOUND)

    recruiter_profile.delete()  # Supprime le profil recruteur
    return Response(status=status.HTTP_204_NO_CONTENT)

@api_view(['POST'])
def recruiter_signup(request):
    serializer = RecruiterSignupSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

permission_classes = [AllowAny]  # Pas de restriction d'accès
@api_view(['GET'])
def get_all_users(request):
    users = User.objects.all()
    serializer = UserSerializer(users, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)

@api_view(['GET'])
def get_all_candidates(request):
    candidates = User.objects.filter(role='candidate')
    serializer = UserSerializer(candidates, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)

@api_view(['GET'])
def get_all_recruiters(request):
    recruiters = User.objects.filter(role='recruiter')
    serializer = UserSerializer(recruiters, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)

@api_view(['PUT'])
def user_update(request, pk):
    try:
        user = User.objects.get(pk=pk)
    except User.DoesNotExist:
        return Response({"detail": "Utilisateur non trouvé."}, status=status.HTTP_404_NOT_FOUND)

    if request.method == 'PUT':
        serializer = UserSerializer(user, data=request.data)
        if serializer.is_valid():
            serializer.save()  # Sauvegarder les données validées
            return Response(serializer.data)
        else:
            print(serializer.errors)  # Affiche les erreurs du sérialiseur
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# Fonction pour gérer la suppression d'un utilisateur
@api_view(['DELETE'])
def user_delete(request, pk):
    try:
        user = User.objects.get(pk=pk)
    except User.DoesNotExist:
        return Response({"detail": "Utilisateur non trouvé."}, status=status.HTTP_404_NOT_FOUND)

    if request.method == 'DELETE':
        user.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)